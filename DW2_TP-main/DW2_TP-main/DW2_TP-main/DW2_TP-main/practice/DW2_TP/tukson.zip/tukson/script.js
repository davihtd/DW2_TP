const form = document.getElementById("myForm");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const messageInput = document.getElementById("message");
const messagesList = document.getElementById("messages");

// Cargar mensajes existentes del LocalStorage al cargar la página
window.addEventListener("DOMContentLoaded", () => {
  loadMessages();
});

// Agregar evento de envío del formulario
form.addEventListener("submit", (e) => {
  e.preventDefault(); // Evitar el envío del formulario

  // Obtener los valores del formulario
  const name = nameInput.value;
  const email = emailInput.value;
  const message = messageInput.value;

  // Validar que se hayan ingresado todos los campos
  if (name === "" || email === "" || message === "") {
    alert("Por favor, complete todos los campos");
    return;
  }

  // Crear un objeto de mensaje
  const newMessage = {
    name,
    email,
    message,
    createdAt: new Date().toLocaleString(),
  };

  // Obtener los mensajes existentes del LocalStorage
  const messages = getMessages();

  // Agregar el nuevo mensaje al arreglo
  messages.push(newMessage);

  // Guardar los mensajes actualizados en el LocalStorage
  saveMessages(messages);

  // Limpiar el formulario
  nameInput.value = "";
  emailInput.value = "";
  messageInput.value = "";

  // Recargar la lista de mensajes
  loadMessages();
});

// Obtener los mensajes existentes del LocalStorage
function getMessages() {
  const messages = localStorage.getItem("messages");
  return messages ? JSON.parse(messages) : [];
}

// Guardar los mensajes en el LocalStorage
function saveMessages(messages) {
  localStorage.setItem("messages", JSON.stringify(messages));
}

// Cargar y mostrar los mensajes en la lista
function loadMessages() {
  messagesList.innerHTML = ""; // Limpiar la lista antes de cargar los mensajes

  const messages = getMessages();

  if (messages.length === 0) {
    messagesList.innerHTML =
      '<div class="row"><div class="col">No hay mensajes guardados</div></div>';
  } else {
    messages.forEach((message, index) => {
      const row = document.createElement("div");
      row.classList.add("row", "message-item");
      row.classList.add("row", "mt-2");

      const colNameEmail = document.createElement("div");
      colNameEmail.classList.add("col");
      colNameEmail.innerHTML = `
  <div class="message-item">
    <span class="name-email">${message.name}</span> |
    <span class="name-email">${message.email}</span>
    <br>
    <span class="created-at">${message.createdAt}</span> <!-- Agrega la fecha de creación aquí -->
  </div>
`;
      row.appendChild(colNameEmail);

      const colMessage = document.createElement("div");
      colMessage.classList.add("col");
      colMessage.innerHTML = `
          <span>${message.message}</span>
        `;
      row.appendChild(colMessage);

      const colActions = document.createElement("div");
      colActions.classList.add("col", "d-flex", "align-items-center");
      colActions.innerHTML = `
          <button class="btn btn-sm btn-primary mr-2" onclick="editMessage(${index})">Editar</button>
          <button class="btn btn-sm btn-danger" onclick="deleteMessage(${index})">Eliminar</button>
        `;
      row.appendChild(colActions);

      messagesList.appendChild(row);
    });
  }
}

// Editar un mensaje existente
function editMessage(index) {
  const messages = getMessages();
  const message = messages[index];

  nameInput.value = message.name;
  emailInput.value = message.email;
  messageInput.value = message.message;

  // Eliminar el mensaje existente del arreglo
  messages.splice(index, 1);

  // Guardar los mensajes actualizados en el LocalStorage
  saveMessages(messages);

  // Recargar la lista de mensajes
  loadMessages();
}

// Eliminar un mensaje existente
function deleteMessage(index) {
  const messages = getMessages();

  // Eliminar el mensaje existente del arreglo
  messages.splice(index, 1);

  // Guardar los mensajes actualizados en el LocalStorage
  saveMessages(messages);

  // Recargar la lista de mensajes
  loadMessages();
}
